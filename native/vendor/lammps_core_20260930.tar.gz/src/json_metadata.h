/* -*- c++ -*- ----------------------------------------------------------
   LAMMPS - Large-scale Atomic/Molecular Massively Parallel Simulator
   https://www.lammps.org/, Sandia National Laboratories
   LAMMPS development team: developers@lammps.org

   Copyright (2003) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level LAMMPS directory.
------------------------------------------------------------------------- */

#ifndef LMP_JSON_METADATA_H
#define LMP_JSON_METADATA_H

// full declaration of JSON metadata struct, used in JSON dump molecules format

namespace LAMMPS_NS {
  struct json_metadata {
    std::string key;                                  // JSON key
    std::vector<std::string> values;                  // JSON value
    int *ivec;                                        // per-atom vector, indices for 'values'
  };
}
#endif
