"""Independent SimVascular feasibility validation."""
