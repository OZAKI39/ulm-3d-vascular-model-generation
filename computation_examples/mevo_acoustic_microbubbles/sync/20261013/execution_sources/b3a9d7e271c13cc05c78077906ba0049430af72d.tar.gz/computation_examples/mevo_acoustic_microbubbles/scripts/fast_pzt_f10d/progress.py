"""Single minimal insertion; preserve every previous byte and heading."""

import difflib
from pathlib import Path
from .common import BASE, sha, write

ADDITION = """**F10D让每颗泡泡的数据更快整理出来。**沿用F10C已经通过的完整逐泡批量路径，这次没有改声力、润滑、接触、血流或墙面。先读取已有B64轨迹定位热点：大量逐帧Python调用、稀疏连通图转换和重复形状统计比单独Kabsch更贵。用NumPy批量计算、复用形状量，并只省去成员完全没变时的重复集合比较后，正式同数组warm后处理从5.654 s降至1.299 s。每泡ID、全部位置、形态指标、接受步连边和原质量记录仍然保存；尝试的HDF5 shuffle反而更慢、更大，因此保留原gzip设置。

**完整程序也实际快了。**同一空闲RTX4090窗口内，B16驻留完整输出从2.444 s降至1.377 s，B64从6.856 s降至2.658 s；全新进程分别从3.511 s降至2.509 s、8.631 s降至4.005 s。B64冷进程加速2.155倍，超过事先登记的1.25倍目标。每项只有一个有限配对，仍是32泡、10 ms、201帧基准；没有把历史F10C计时直接当本轮分母。全部原始物理数据和离散事件保持原值，只有主轴角末位有舍入差，最大2.714e-7度，小于预登记1e-5度。

**不同PZT控制可以先分家族，再共用静态资源。**OFF、原相位S和优化相位O按完整控制日程哈希分三组，本轮5、7、8条均完成；实际20条串行对照全部一致，输入顺序和身份也能恢复。分组驻留成本比逐条计算快4.775倍，计入共同静态准备后快4.153倍，总体折算约21293条数值通过轨迹/GPU小时。它们是平移和复制的性能样本，不能称为独立科学数据；1 kPa指原初态局部压力，沿用F10A独立高驱动源配置，不是历史291.2377 Pa源上限内的新结果。

**真正不同的排列暴露了下一处难点。**按预登记四个种子生成不同的32泡排列并用原模型准备，只有两个在10 ms完整通过且连成32泡团；另外两个因原接触预算失败。对通过准备的两个初态继续O/S/OFF控制，只有两条OFF完成，O和S各有一泡对提案重叠超过原17.8 nm预算，停止整批，也各中止了一条当时未见该超限的同行轨迹。失败、接受前缀、拒绝提案和sample_id都保留，没有重试挑成功者，也没有放宽预算。原共享错误位只给出50 µs主机检查区间，本轮没有伪造首错子步时刻。

**形态变化仍用真实历史数据核对。**F5原600 ms关声释放轨迹的1201帧、674条接受步边记录，33次持续合并、11次持续分裂和1次右删失分裂都由新旧后处理一致恢复；关声时最大团32泡，末尾7泡。这些是几何图的分裂/合并，不是物理破裂/融合。四种子新初态及失败前缀也完成后处理回归。计入全部准备、失败和分支运行，4.561 s留下两个独立seed的合格OFF分支，短样本折算约1579个/GPU小时；没有任何初态完成全部三控制，配套三控制数据产量为0，不能把基准每小时数万条套用过来。

> **F10D证据与下一步：**`docs/FAST_PZT_F10D_DEVELOPMENT.md`、`docs/FAST_PZT_F10D_PERFORMANCE.md`和`results/fast_pzt/f10d/`保存固定commit、原输入哈希、实测时钟、全部失败、四组英文PNG/PDF及回传核验。当前工程优化通过，多样化控制覆盖未通过；仍是 **EXPLORATORY / PHYSICS_UNCALIBRATED，training_ready=false**。F10E应先补齐逐成员首错诊断，再严格验证失败隔离与重试成本，并检查独立密团接触的稳健性；同一seed的所有分支留在同一个数据家族，不能靠复制或控制分支制造AI泛化。

"""


def main():
    path = Path("/home/lzy/projects/microbubble_aggregation.md")
    backup = path.with_name(path.name + ".bak_F10D_20261011")
    folder = BASE / "progress_document"
    folder.mkdir(exist_ok=True)
    marker = "---\n\n### 尾声：故事里还没讲完的部分"
    before = path.read_text()
    assert before.count(marker) == 1 and "**F10D让每颗泡泡" not in before
    assert not backup.exists(), "Do not overwrite an existing historical backup"
    with backup.open("xb") as handle:
        handle.write(path.read_bytes())
    after = before.replace(marker, ADDITION + marker)
    assert after.replace(ADDITION, "", 1) == before

    def headings(value):
        return [line for line in value.splitlines() if line.startswith("#")]

    assert headings(before) == headings(after)
    (folder / "before.md").write_text(before)
    (folder / "after.md").write_text(after)
    (folder / "addition.md").write_text(ADDITION)
    (folder / "change.diff").write_text(
        "".join(
            difflib.unified_diff(
                before.splitlines(True), after.splitlines(True), fromfile="before.md", tofile="after.md"
            )
        )
    )
    path.write_text(after)
    write(
        folder / "VERIFICATION.json",
        dict(
            status="PASS",
            original_path=str(path),
            backup=str(backup),
            before_sha256=sha(backup),
            after_sha256=sha(path),
            headings_before=headings(before),
            headings_after=headings(after),
            old_bytes_retained=True,
            inserted_section_only=True,
        ),
    )
    print("Progress document updated; all prior text and headings preserved")


if __name__ == "__main__":
    main()
