"""Repair failed/rejected leaves, then audit a NEW independent holdout set."""
import argparse
import json
from pathlib import Path
import numpy as np
from mevo_mb.bubbles.adaptive_table import AdaptiveResponseTableBuilder,CORNERS
from common import atomic_json


def main():
    p=argparse.ArgumentParser();p.add_argument('run');a=p.parse_args();path=Path(a.run)
    config=json.loads((path/'CHECKPOINT.json').read_text())['config']
    b=AdaptiveResponseTableBuilder(path,'third_party/build/apecss/ultrasound_apecss','configs/stage2/sonovue_parameters.json',
        profile=config['profile'],workers=7,cache='results/stage2_5/response_table/node_cache')
    failed=[r['point'] for r in json.loads((path/'HOLDOUTS.json').read_text())['independent_uniform_queries'] if r['status']=='FAIL']
    keep=[]
    for cell in b.leaves:
        lo,hi=np.array(cell['lo']),np.array(cell['hi'])
        requires=cell['status']=='INVALID_CELL' or any(np.all(np.array(p)>=lo)&np.all(np.array(p)<=hi) for p in failed)
        if requires and cell['depth']+3<=config['max_depth'] and len(b.nodes)<config['max_nodes']:
            half=(hi-lo)/2
            for corner in CORNERS:
                aa=lo+corner*half;b.queue.append(dict(lo=aa.tolist(),hi=(aa+half).tolist(),depth=cell['depth']+3))
        else:keep.append(cell)
    b.leaves=keep;b.checkpoint();result=b.build();atomic_json(path/'REPAIR_RESULT.json',result)

if __name__=='__main__':main()
