"""Explicit operational validity limits; thresholds are policies, not universal laws."""
from dataclasses import dataclass, asdict

import numpy as np


class PhysicsValidityError(RuntimeError):
    pass


@dataclass(frozen=True)
class PairInteractionValidity:
    min_distance_over_radius: float = 10.
    min_distance_over_sum: float = 5.
    max_radial_fraction: float = .2
    max_kd: float = .3

    def check(self, positions, radii, radial_fraction, frequency, sound_speed):
        x, r = np.asarray(positions), np.asarray(radii)
        i,j = np.triu_indices(len(r),1)
        d = np.linalg.norm(x[i]-x[j],axis=1)
        ri,rj = d/r[i],d/r[j]
        rs = d/(r[i]+r[j])
        amplitude = np.asarray(radial_fraction)
        near = (ri<self.min_distance_over_radius)|(rj<self.min_distance_over_radius)|(rs<self.min_distance_over_sum)
        high = (amplitude[i]>self.max_radial_fraction)|(amplitude[j]>self.max_radial_fraction)
        retardation = 2*np.pi*frequency*d/sound_speed>self.max_kd
        valid = ~near & ~high & ~retardation
        return dict(pair_count=len(d), valid_pair_count=int(valid.sum()),
                    far_field_fraction=float(valid.mean()) if len(d) else 1.,
                    near_field_pairs=int(near.sum()), amplitude_invalid_pairs=int(high.sum()),
                    retardation_invalid_pairs=int(retardation.sum()), contact_count=int((rs<=1).sum()),
                    minimum_pair_separation_m=float(d.min()) if len(d) else None,
                    min_d_over_Ri=float(ri.min()) if len(d) else None,
                    min_d_over_Rj=float(rj.min()) if len(d) else None,
                    min_d_over_sum=float(rs.min()) if len(d) else None)


class PhysicsValidityMonitor:
    def __init__(self, radial_model, *, policy="strict", pair=None, min_wall_distance_over_radius=5.):
        if policy not in ("strict","legacy_demo","pair_reference"):
            raise ValueError("Unknown near_field_policy")
        self.radial_model,self.policy=radial_model,policy
        self.pair=pair or PairInteractionValidity()
        self.wall_ratio=min_wall_distance_over_radius
        self.history=[]
        self.last={}

    def observe(self, positions, radii, time_s, *, radial_fraction, frequency, sound_speed,
                wall_distance_m=None, response_valid=True, harmonic_resolved=True,
                secondary_enabled=True):
        check=self.pair.check(positions,radii,radial_fraction,frequency,sound_speed)
        walls=0 if wall_distance_m is None else int(np.sum(np.asarray(wall_distance_m)/radii<self.wall_ratio))
        reasons=[]
        if not response_valid:
            reasons.append("response table bounds/cell/medium invalid")
        if not harmonic_resolved and secondary_enabled:
            reasons.append("secondary-force harmonic truncation unresolved")
        if secondary_enabled and check["near_field_pairs"]:
            reasons.append("pair separation outside far-field policy")
        if secondary_enabled and check["retardation_invalid_pairs"]:
            reasons.append("quasistatic acoustic retardation limit exceeded")
        if np.max(radial_fraction)>self.pair.max_radial_fraction:
            reasons.append("oscillation amplitude exceeds configured small-motion limit")
        if walls:
            reasons.append("near-wall hydrodynamics unvalidated")
        self.last=dict(time_s=float(time_s),radial_model=self.radial_model,near_field_policy=self.policy,
                       within_response_table=bool(response_valid),max_radial_fraction=float(np.max(radial_fraction)),
                       wall_events=walls,invalid_reason=reasons,**check)
        self.history.append(self.last.copy())
        if reasons and self.policy=="strict":
            raise PhysicsValidityError("; ".join(reasons))
        return self.last

    def summary(self):
        counts=sum(x["pair_count"] for x in self.history)
        valid=sum(x["valid_pair_count"] for x in self.history)
        return dict(**self.last, policy_thresholds=asdict(self.pair), checks=len(self.history),
                    sample_weighted_far_field_fraction=valid/counts if counts else 1.,
                    near_field_events=sum(x["near_field_pairs"] for x in self.history),
                    total_wall_events=sum(x["wall_events"] for x in self.history),
                    physics_status="demo only" if self.policy=="legacy_demo" else
                    ("outside validity" if any(x["invalid_reason"] for x in self.history) else "partially validated"),
                    note="Fractions count evaluations including RK stages, not a time integral; passing policies is not experimental validation")
