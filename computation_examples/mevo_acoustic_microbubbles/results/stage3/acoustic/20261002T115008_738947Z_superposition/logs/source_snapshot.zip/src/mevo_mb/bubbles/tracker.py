"""Slow-time RK integration with explicit geometric feasibility guards and audit logs."""

from __future__ import annotations

import json
import time
from pathlib import Path

import h5py
import numpy as np
import pandas as pd

from mevo_mb.bubbles.contact import constrain_pair_velocities, project_contacts
from mevo_mb.bubbles.forces import NumpyPairBackend, ClassicalFarFieldBjerknes, primary_bjerknes
from mevo_mb.bubbles.metrics import aggregation_metrics
from mevo_mb.bubbles.population import BubblePopulation
from mevo_mb.bubbles.response import LinearResonantBubbleModel
from mevo_mb.bubbles.response_table import ResponseTableBubbleModel
from mevo_mb.bubbles.adaptive_table import AdaptiveResponseTableBubbleModel
from mevo_mb.bubbles.validity import PhysicsValidityMonitor, PairInteractionValidity, PhysicsValidityError
from mevo_mb.coupling.geometry import Cylinder
from mevo_mb.flow.fields import FlowField
from mevo_mb.io.artifacts import write_json


class ParticleTracker:
    """Fixed nominal RK2/RK4 clock, optional displacement-limited internal substeps.

    Every accepted substep is saved. Displacement guards establish geometry safety,
    not integration-error convergence. Contact stages use geometric projections.
    """

    def __init__(self, config: dict, acoustic_field, flow: FlowField):
        self.config, self.field, self.flow = config, acoustic_field, flow
        self.p = config["particles"]
        self.cylinder = Cylinder(**config["vessel"])
        response = config["bubble_response"]
        # Old explicitly-surrogate configurations retain their baseline behavior,
        # always labelled DEMO ONLY. New response-table runs default to strict.
        self.policy = self.p.get(
            "near_field_policy", "legacy_demo" if response["model"] == "linear_surrogate" else "strict"
        )
        self.monitor = PhysicsValidityMonitor(
            response["model"],
            policy=self.policy,
            pair=PairInteractionValidity(**config.get("physics_validity", {}).get("pair", {})),
            min_wall_distance_over_radius=config.get("physics_validity", {}).get(
                "min_wall_distance_over_radius", 5.0
            ),
            regime_map_path=config.get('physics_validity', {}).get('regime_map_path'),
            max_invalid_pair_fraction=config.get('physics_validity', {}).get('max_invalid_pair_fraction', 0.0),
            max_transition_pair_fraction=config.get('physics_validity', {}).get('max_transition_pair_fraction', 0.05),
        )
        if self.policy == "pair_reference":
            # Full coupled reference has its own radial/translation integrator.
            # It cannot be inserted as an N-body force sum or combined with flow.
            self.response = self.pair = None
            return
        if response["model"] in ("response_table", "adaptive_response_table"):
            table_class = AdaptiveResponseTableBubbleModel if response['model']=='adaptive_response_table' else ResponseTableBubbleModel
            self.response = table_class(
                response["path"], backend=self.p.get("response_backend", 'numpy' if self.p.get('pair_backend')=='auto' else self.p.get("pair_backend", "numpy"))
            )
            self.monitor.response_context = {
                "table": str(self.response.path),
                "metadata": self.response.metadata,
                "axis_bounds_SI": {
                    k: [float(a[0]), float(a[-1])]
                    for k, a in zip(("radius_m", "frequency_Hz", "pressure_Pa"), self.response.axes)
                },
                "extrapolation_allowed": False,
                "validated_cells_required": True,
                "shell_parameters": "Fixed table parameter manifold; other shell parameters require another table",
                "experimental_shell_calibration_validated": False,
            }
        elif response["model"] == "linear_surrogate" and self.policy == "legacy_demo":
            self.response = LinearResonantBubbleModel(
                response["resonance_frequency_Hz"], response["damping_ratio"]
            )
        else:
            raise ValueError(
                "Strict trajectories require a validated response table; linear surrogate is demo only"
            )
        if self.policy == "legacy_demo":
            self.pair = NumpyPairBackend(
                self.p["minimum_separation_m"],
                self.p["collision_regularization_m"],
                self.p["secondary_force_cutoff_m"],
            )
        else:
            if self.p.get('pair_backend') == 'auto':
                from mevo_mb.bubbles.auto_backend import AutoPairBackend
                self.pair = AutoPairBackend(benchmark_path=self.p.get('pair_benchmark_path', 'results/stage2/performance/STATE.json'),
                    crossover=self.p.get('pair_crossover'),min_distance_over_sum=self.monitor.pair.min_distance_over_sum)
            else:
                self.pair = ClassicalFarFieldBjerknes(
                    self.p.get("pair_backend", "numpy"),
                    min_distance_over_sum=self.monitor.pair.min_distance_over_sum,
                )

    def evaluate(self, x, radii, t):
        self._last_query = dict(
            positions_m=np.array(x, copy=True), radii_m=np.array(radii, copy=True), time_s=float(t)
        )
        pressure = self.field.interpolate_complex_pressure(x)
        gradient = self.field.interpolate_complex_gradient(x)

        def cpu(value):
            return value.get() if hasattr(value, "get") else np.asarray(value)

        pair_volume = None
        resolved = True
        try:
            if isinstance(self.response, ResponseTableBubbleModel):
                self.response.validate_medium(self.config["medium"])
                q = self.response.harmonic_response(radii, self.field.frequency_Hz, pressure)
                pair_volume = q["harmonics_m3"]
                volume = cpu(pair_volume[..., 0])
                radial_fraction = np.maximum(
                    cpu(q["corner_envelope_max_R_over_R0"]) - 1, 1 - cpu(q["corner_envelope_min_R_over_R0"])
                )
                resolved = bool(cpu(q["harmonic_resolved"]).all())
            else:
                volume = cpu(
                    self.response.response(radii, self.field.frequency_Hz, pressure, self.config["medium"])
                )
                radial_fraction = np.abs(volume) / (4 * np.pi * radii**3)
        except ValueError as error:
            self.monitor.observe(
                x,
                radii,
                t,
                radial_fraction=np.zeros_like(radii),
                frequency=self.field.frequency_Hz,
                sound_speed=self.config["medium"]["sound_speed_m_s"],
                response_valid=False,
                secondary_enabled=self.p["secondary_enabled"],
            )
            raise PhysicsValidityError(str(error)) from error
        wall_distance = np.minimum(
            self.cylinder.radius_m - np.linalg.norm(x[:, 1:], axis=1),
            self.cylinder.length_m / 2 - np.abs(x[:, 0]),
        )
        self.monitor.observe(
            x,
            radii,
            t,
            radial_fraction=radial_fraction,
            frequency=self.field.frequency_Hz,
            sound_speed=self.config["medium"]["sound_speed_m_s"],
            wall_distance_m=wall_distance,
            harmonic_resolved=resolved,
            secondary_enabled=self.p["secondary_enabled"],
            pressure_amplitude=np.abs(pressure),
            pressure_phase_rad=np.angle(pressure),
            shell_model=self.config['bubble_response'].get('shell_model', self.config['bubble_response']['model']),
        )
        primary = primary_bjerknes(volume, gradient) if self.p["primary_enabled"] else np.zeros_like(x)
        secondary = (
            cpu(
                self.pair.forces(
                    x,
                    radii,
                    pair_volume if pair_volume is not None and self.policy != "legacy_demo" else volume,
                    self.field.frequency_Hz,
                    self.config["medium"]["density_kg_m3"],
                )
            )
            if self.p["secondary_enabled"]
            else np.zeros_like(x)
        )
        flow = self.flow.velocity(x, t)
        free = flow + (primary + secondary) / (
            6 * np.pi * self.config["medium"]["viscosity_Pa_s"] * radii[:, None]
        )
        velocity = self.cylinder.constrain_velocity(x, radii, free)
        velocity = constrain_pair_velocities(
            x, radii, velocity, self.p["contact_tolerance_m"], self.p["contact_max_iterations"]
        )
        velocity = self.cylinder.constrain_velocity(x, radii, velocity)
        if not np.isfinite(velocity).all():
            raise RuntimeError("Nonfinite translation velocity")
        return {
            "primary_force_N": primary,
            "secondary_force_N": secondary,
            "flow_velocity_m_s": flow,
            "free_total_velocity_m_s": free,
            "total_velocity_m_s": velocity,
            "local_pressure_complex_Pa": pressure,
            "volume_response_complex_m3": volume,
        }

    def _project(self, x, radii):
        return project_contacts(
            x, radii, self.cylinder, self.p["contact_tolerance_m"], self.p["contact_max_iterations"]
        )

    def step(self, x, radii, t, dt, first):
        def velocity(position, at):
            feasible, _, _, _ = self._project(position, radii)
            return self.evaluate(feasible, radii, at)["total_velocity_m_s"]

        k1 = first["total_velocity_m_s"]
        k2 = velocity(x + dt * k1 / 2, t + dt / 2)
        if self.p["integrator"] == "RK2":
            proposed = x + dt * k2
        elif self.p["integrator"] == "RK4":
            k3 = velocity(x + dt * k2 / 2, t + dt / 2)
            k4 = velocity(x + dt * k3, t + dt)
            proposed = x + dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6
        else:
            raise ValueError("Integrator must be RK2 or RK4")
        corrected, wall, contacts, iterations = self._project(proposed, radii)
        return (
            corrected,
            wall,
            contacts,
            float(np.max(np.linalg.norm(corrected - proposed, axis=1))),
            iterations,
        )

    def run(self, population: BubblePopulation, run: Path) -> dict:
        if self.policy == "pair_reference":
            from mevo_mb.validation.pair_policy import run_pair_reference

            return run_pair_reference(self.config, population, run, self.field, self.flow)
        try:
            return self._run(population, run)
        except PhysicsValidityError as error:
            # Preserve both the last accepted trajectory and rejected RK-stage
            # coordinates; do not mark an incomplete trajectory complete.
            report = {
                "status": "OUTSIDE_VALIDITY",
                "error": str(error),
                "physics_validity": self.monitor.summary(),
            }
            write_json(run / "particles/SUMMARY.json", report)
            write_json(run / "physics_validity.json", self.monitor.summary())
            if hasattr(self, "_last_query"):
                np.savez(run / "particles/rejected_state.npz", **self._last_query)
            raise

    def _run(self, population: BubblePopulation, run: Path) -> dict:
        start = time.perf_counter()
        last_progress = start
        x, radii = population.positions_m.copy(), population.radii_m
        if len(radii) < 2:
            raise ValueError("Population metrics require at least two bubbles")
        duration, nominal = self.p["duration_s"], self.p["dt_s"]
        time_s, accepted, subdivisions, contact_events, wall_events = 0.0, 0, 0, 0, 0
        max_projection, max_radial_fraction = 0.0, 0.0
        minimum_dt = nominal
        metric_rows = []
        file = run / "particles/trajectories.h5"
        with h5py.File(file, "x") as h5, (run / "particles/events.jsonl").open("x") as events:
            h5.attrs["velocity_semantics"] = (
                "Instantaneous force/drag velocity at saved state; not the preceding displacement divided by dt. All accepted substeps saved."
            )
            h5.attrs["model"] = (
                f"{self.config['bubble_response']['model']}; {self.policy}; quasisteady Stokes; geometric contact only"
            )
            h5.attrs["physics_status"] = (
                "NOT PHYSICALLY VALIDATED" if self.policy == "legacy_demo" else "partially validated"
            )
            h5.create_dataset("radii_m", data=radii)
            h5.create_dataset("particle_id", data=population.ids)
            datasets = {}

            def record(at, position, data, wall, actual_dt):
                nonlocal max_radial_fraction
                self.monitor.record_accepted_interval(actual_dt)
                metric, labels, hist, edges = aggregation_metrics(position, radii, self.config["metrics"])
                metric.update(
                    time_s=at,
                    mean_displacement_m=float(
                        np.linalg.norm(position - population.positions_m, axis=1).mean()
                    ),
                    mean_lateral_displacement_m=float(
                        np.linalg.norm(position[:, 1:] - population.positions_m[:, 1:], axis=1).mean()
                    ),
                )
                metric.update({'pair_regime_'+k:v for k,v in self.monitor.last['pair_regime'].items() if k.endswith('_fraction')})
                metric_rows.append(metric)
                max_radial_fraction = max(
                    max_radial_fraction,
                    float(np.max(np.abs(data["volume_response_complex_m3"]) / (4 * np.pi * radii**3))),
                )
                items = {
                    "time_s": np.array(at),
                    "accepted_dt_s": np.array(actual_dt),
                    "positions_m": position,
                    "cluster_labels": labels,
                    "wall_hit": wall,
                    "pair_distance_histogram": hist,
                    **data,
                }
                for name, value in items.items():
                    value = np.asarray(value)
                    if name not in datasets:
                        datasets[name] = h5.create_dataset(
                            name,
                            shape=(0,) + value.shape,
                            maxshape=(None,) + value.shape,
                            chunks=(1,) + value.shape,
                            dtype=value.dtype,
                            compression="gzip",
                            compression_opts=1,
                        )
                    ds = datasets[name]
                    ds.resize(len(metric_rows), axis=0)
                    ds[-1] = value
                if "pair_distance_histogram_edges_m" not in h5:
                    h5.create_dataset("pair_distance_histogram_edges_m", data=edges)

            state = self.evaluate(x, radii, time_s)
            record(0.0, x, state, np.zeros(len(radii), bool), 0.0)
            macro_count = int(np.ceil(duration / nominal))
            for macro in range(1, macro_count + 1):
                target = min(macro * nominal, duration)
                local_count = 0
                while time_s < target - 1e-15:
                    speed = np.linalg.norm(state["total_velocity_m_s"], axis=1)
                    geometric_dt = np.min(
                        self.p["max_displacement_per_radius"] * radii / np.maximum(speed, 1e-30)
                    )
                    dt = min(target - time_s, geometric_dt)
                    if dt <= 1e-15:
                        raise RuntimeError(
                            "Translation step collapsed; preserve failure instead of fabricating motion"
                        )
                    x, wall, contacts, correction, _ = self.step(x, radii, time_s, dt, state)
                    time_s = min(time_s + dt, target)
                    state = self.evaluate(x, radii, time_s)
                    accepted += 1
                    local_count += 1
                    minimum_dt = min(minimum_dt, dt)
                    max_projection = max(max_projection, correction)
                    wall_events += int(wall.sum())
                    contact_events += len(contacts)
                    if contacts or wall.any():
                        events.write(
                            json.dumps(
                                {
                                    "time_s": time_s,
                                    "contact_pairs": contacts,
                                    "wall_particle_ids": population.ids[wall].tolist(),
                                    "maximum_projection_m": correction,
                                }
                            )
                            + "\n"
                        )
                    record(time_s, x, state, wall, dt)
                    if time.perf_counter() - last_progress >= 5:
                        h5.flush()
                        write_json(
                            run / "PROGRESS.json",
                            {
                                "time_s": time_s,
                                "duration_s": duration,
                                "accepted_steps": accepted,
                                "elapsed_s": time.perf_counter() - start,
                            },
                        )
                        last_progress = time.perf_counter()
                    if local_count > self.p["max_substeps"]:
                        raise RuntimeError("Substep budget exceeded")
                subdivisions += max(0, local_count - 1)
                if macro % 40 == 0:
                    h5.flush()
                    write_json(
                        run / "PROGRESS.json",
                        {
                            "time_s": time_s,
                            "duration_s": duration,
                            "accepted_steps": accepted,
                            "elapsed_s": time.perf_counter() - start,
                        },
                    )
            h5.attrs["complete"] = True
        pd.DataFrame(metric_rows).to_csv(run / "metrics.csv", index=False)
        summary = {
            "status": "COMPLETE",
            "particle_count": len(radii),
            "duration_s": time_s,
            "nominal_dt_s": nominal,
            "minimum_accepted_dt_s": minimum_dt,
            "accepted_substeps": accepted,
            "additional_geometric_substeps": subdivisions,
            "contact_projection_pair_events": contact_events,
            "wall_hit_events": wall_events,
            "maximum_projection_m": max_projection,
            "maximum_linear_radial_amplitude_over_R0": max_radial_fraction,
            "radial_surrogate_validated_for_SonoVue": False,
            "initial": metric_rows[0],
            "final": metric_rows[-1],
            "elapsed_s": time.perf_counter() - start,
            "trajectory_file": str(file),
            "aggregation_definition": "spatial clustering, no coalescence",
            "all_accepted_substeps_recorded": True,
        }
        summary["physics_validity"] = self.monitor.summary()
        summary['pair_regime'] = summary['physics_validity']['pair_regime']
        summary['validity_status'] = summary['physics_validity']['validity_status']
        if hasattr(self.pair, 'decisions'):
            summary['pair_backend_decisions'] = self.pair.decisions
        if isinstance(self.response, ResponseTableBubbleModel):
            summary["maximum_fundamental_volume_equivalent_radial_fraction"] = summary.pop(
                "maximum_linear_radial_amplitude_over_R0"
            )
            summary["maximum_radial_excursion_over_R0"] = max(
                item["max_radial_fraction"] for item in self.monitor.history
            )
            summary["SonoVue_experimental_calibration_validated"] = False
        write_json(run / "physics_validity.json", self.monitor.summary())
        write_json(run / "particles/SUMMARY.json", summary)
        return summary
