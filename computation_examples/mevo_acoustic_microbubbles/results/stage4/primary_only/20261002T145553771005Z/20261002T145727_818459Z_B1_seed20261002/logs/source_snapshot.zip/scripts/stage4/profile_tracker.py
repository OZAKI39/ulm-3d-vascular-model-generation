"""Short instrumented real-CFD case, separate from formal branch statistics."""
import cProfile
import io
import pstats
from scripts.stage4.common import new_run, finish
from scripts.stage4.experiments import setup,run_case


def main():
    provided = setup()
    out = new_run("performance/profile",dict(duration_s=.02,case="B0",purpose="Measured runtime diagnosis"),["phase_screening"])
    profiler = cProfile.Profile()
    profiler.enable()
    row = run_case(out,"B0",provided[1]["particles"]["seed"],duration=.02,provided=provided)
    profiler.disable()
    profiler.dump_stats(str(out / "tracker.prof"))
    text = io.StringIO()
    pstats.Stats(profiler,stream=text).sort_stats("cumulative").print_stats(35)
    (out / "PROFILE.txt").write_text(text.getvalue())
    print(text.getvalue(),flush=True)
    finish(out,dict(status="PASS",row=row,scope="Instrumented short runtime sample, not branch-control evidence"))


if __name__ == "__main__":
    main()
