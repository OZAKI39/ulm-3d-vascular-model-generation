"""Immutable paired Y-control runs; production forces and FlowField API are reused."""
import argparse
import copy
import json
import time
import numpy as np
import yaml
from mevo_mb.acoustics.basis import ComplexAcousticField
from mevo_mb.bubbles.inlet_sampling import initialize_inlet
from mevo_mb.coupling.bifurcation_experiment import BifurcationExperimentTracker
from mevo_mb.coupling.geometry import geometry_from_config
from mevo_mb.flow.fields import VTKFlowField
from mevo_mb.io.artifacts import new_run as particle_run
from mevo_mb.utils.config import load_config
from scripts.stage4.common import ROOT, new_run, require, sha, write, finish
from scripts.stage4.synthetic import AcousticOff


def setup():
    geometry = yaml.safe_load((ROOT / "configs/stage4/bifurcation.yaml").read_text())
    protocol = yaml.safe_load((ROOT / "configs/stage4/experiment.yaml").read_text())
    source = require("simvascular/steady")
    imported = require("simvascular/import")
    mesh = require("simvascular/mesh")
    acoustic = require("acoustic")
    controls = require("phase_screening")
    config = load_config(ROOT / "configs/stage3/cylinder.yaml")
    config["geometry"] = dict(geometry["geometry"],kind="bifurcation",
        mesh_surface=str((ROOT / mesh["mesh"]).parent / "mesh-complete.exterior.vtp"))
    config["medium"] = geometry["medium"]
    config["particles"].update(protocol["particles"])
    config["output"].update(protocol["output"])
    config["classification_tolerance_m"] = geometry["geometry"]["classification_tolerance_m"]
    config["bubble_response"]["path"] = controls["response_table"]
    config["experiment_scope"] = "Stage4 finite initial ensemble, homogeneous water, geometric walls; no clinical concentration or patient calibration"
    flow = VTKFlowField(ROOT / source["snapshot"],velocity_array=source["velocity_array"],
                        coordinate_scale_to_m=source["coordinate_scale_to_m"],
                        velocity_scale_to_m_s=source["velocity_scale_to_m_s"],spatial_method=imported["spatial_method"])
    identity = dict(geometry_hash=source["geometry_hash"],mesh_sha256=source["mesh_sha256"],
                    flow_sha256=source["snapshot_sha256"],acoustic_basis_sha256=acoustic["basis_sha256"],
                    response_table_sha256=sha(ROOT / controls["response_table"]))
    return config,geometry,protocol,flow,controls,identity


def run_case(parent,label,seed,*,secondary=False,dt_factor=1.,policy=None,count=None,
             field_override=None,tolerance=None,duration=None,provided=None):
    config,geometry,protocol,flow,controls,identity = provided if provided is not None else setup()
    config = copy.deepcopy(config)
    sampling = dict(geometry["particles"],seed=int(seed))
    if policy is not None:
        sampling["sampling_policy"] = policy
    if count is not None:
        sampling["count"] = int(count)
    config["particles"].update(primary_enabled=label != "B0",secondary_enabled=secondary,
                              dt_s=config["particles"]["dt_s"]*dt_factor,count=sampling["count"])
    if duration is not None:
        config["particles"]["duration_s"] = duration
    if tolerance is not None:
        config["classification_tolerance_m"] = tolerance
    config["seed"],config["sampling"] = int(seed),sampling
    control = controls["cases"][label]
    config["pzt_control"] = control
    load_start = time.perf_counter()
    field = AcousticOff() if label == "B0" else ComplexAcousticField.load(ROOT / (field_override or control["field"]))
    load_seconds = time.perf_counter()-load_start
    g = geometry_from_config(config)
    population = initialize_inlet(g,flow,sampling)
    out = particle_run(parent,label+"_seed"+str(seed),config)
    initial = out / "INITIAL_POPULATION.npz"
    np.savez_compressed(initial,positions_m=population.positions_m,radii_m=population.radii_m,particle_id=population.ids)
    import hashlib
    initial_hash = hashlib.sha256(population.positions_m.tobytes()+population.radii_m.tobytes()+population.ids.tobytes()).hexdigest()
    write(out / "RUN_IDENTITY.json",dict(identity,particle_seed=int(seed),initial_population_sha256=initial_hash,
           acoustic_field_sha256=sha(ROOT / (field_override or control["field"])) if label != "B0" else None,
           acoustic_OFF=label == "B0",control_case=label,secondary_enabled=secondary,config=config))
    tracker = BifurcationExperimentTracker(config,field,flow)
    summary = tracker.run(population,out)
    summary["timings"]["acoustic_loading_s"] = load_seconds
    write(out / "particles/SUMMARY.json",summary)
    row = dict(case=label,seed=int(seed),secondary=secondary,run=str(out.relative_to(ROOT)),
                N_A=summary["branch_metrics"]["N_A"],N_B=summary["branch_metrics"]["N_B"],
                N_unassigned=summary["branch_metrics"]["N_unassigned"],N_wall_loss=summary["branch_metrics"]["N_wall_loss"],
                f_A=summary["branch_metrics"]["f_A"],f_B=summary["branch_metrics"]["f_B"],
                initial_population_sha256=initial_hash,elapsed_s=summary["elapsed_s"],timings=summary["timings"])
    print(json.dumps(row),flush=True)
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage",choices=["primary","seeds","secondary"])
    args = parser.parse_args()
    provided = setup()
    config,geometry,protocol,flow,controls,identity = provided
    kind = {"primary":"primary_only","seeds":"statistics/paired_runs","secondary":"primary_secondary"}[args.stage]
    prereq = {"primary":["phase_screening"],"seeds":["primary_only"],"secondary":["statistics"]}[args.stage]
    out = new_run(kind,dict(config=config,protocol=protocol,identity=identity),prereq)
    seeds = geometry["particles"]["seeds"] if args.stage == "seeds" else [geometry["particles"]["seed"]]
    labels = ["B2","B3"] if args.stage == "secondary" else ["B0","B1","B2","B3"]
    rows = []
    # Seed 0 primary trials are reused by identity; no duplicated scientific run.
    existing = require("primary_only")["rows"] if args.stage == "seeds" else []
    for seed in seeds:
        for label in labels:
            previous = next((r for r in existing if r["seed"] == seed and r["case"] == label),None)
            row = previous if previous else run_case(out,label,seed,secondary=args.stage == "secondary",provided=provided)
            rows.append(row)
            write(out / "ROWS.json",rows)
        hashes = {r["initial_population_sha256"] for r in rows if r["seed"] == seed}
        if len(hashes) != 1:
            raise RuntimeError("Paired controls do not share exact initial IDs/positions")
    finish(out,dict(status="PASS_WITH_SCOPE",rows=rows,identity=identity,
                    scope="Execution and paired identity passed; effect and robustness are assessed separately, unassigned outcomes retained"))


if __name__ == "__main__":
    main()
