"""Finite S0 only. No automatic launch of primary, sensitivity or full secondary."""

import argparse
from pathlib import Path

from scripts.stage4l.dense_probe import run

parser = argparse.ArgumentParser()
parser.add_argument("--legacy-root", type=Path, required=True)
parser.add_argument("--duration", type=float, choices=[0.001, 0.005], default=0.001)
parser.add_argument("--backends", nargs="+", default=["lubrication_coupled", "legacy_stokes"], choices=["lubrication_coupled", "legacy_stokes"])
args = parser.parse_args()
for case in ["B2", "B3"]:
    for backend in args.backends:
        run(args.legacy_root, case, backend, args.duration, max_wall_s=600, max_steps=100000)
