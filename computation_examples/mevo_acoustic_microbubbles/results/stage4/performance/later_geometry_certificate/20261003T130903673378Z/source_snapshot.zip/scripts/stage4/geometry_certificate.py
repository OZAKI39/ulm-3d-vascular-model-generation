"""Optional exact no-op certificate for a Stage 4 wall projection.

This helper is not enabled by the experiment runner. A known interior point and
the 1-Lipschitz Euclidean distance bound can prove that a new bubble is still
strictly clear of the same closed surface. No approximate distances are returned
or inserted into the exact query cache. All uncertain cases use the old method.
"""
import numpy as np


def install(geometry):
    original = geometry.project
    counts = dict(calls=0, certified_inactive=0, minimum_certified_margin_m=None)

    def project(positions, radii):
        counts["calls"] += 1
        x = np.asarray(positions)
        previous = geometry._distance_cache
        if geometry._mesh_distance is not None and previous is not None and previous[0].shape == x.shape:
            margin = -previous[1]-np.linalg.norm(x-previous[0], axis=1)-np.asarray(radii)
            unit_gradient = np.abs(np.linalg.norm(previous[2], axis=1)-1.) < 1e-10
            if np.all((previous[1] < 0) & unit_gradient & (margin > 1e-10)):
                counts["certified_inactive"] += 1
                smallest = float(margin.min())
                prior = counts["minimum_certified_margin_m"]
                counts["minimum_certified_margin_m"] = smallest if prior is None else min(prior, smallest)
                return x.copy(), np.zeros(len(x), bool)
        return original(positions, radii)

    geometry.project = project
    return counts
