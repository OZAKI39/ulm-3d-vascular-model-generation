import numpy as np
import pytest
import yaml
from mevo_mb.coupling.bifurcation import BifurcationGeometry, BranchClassifier, Branch


def geometry():
    with open("configs/stage4/bifurcation.yaml") as stream:
        return BifurcationGeometry(yaml.safe_load(stream)["geometry"])


def test_geometry_connected_symmetric_and_finite():
    g = geometry()
    parent = np.column_stack([np.linspace(-.013, 0, 80), np.zeros(80), np.zeros(80)])
    for direction in g.directions.values():
        path = np.vstack([parent, np.linspace(0, .011, 80)[:, None] * direction])
        assert g.contains(path, 1.78e-6).all()
    rng = np.random.default_rng(28)
    x = rng.uniform([-.013, -.006, -.0014], [.011, .006, .0014], (700, 3))
    mirrored = x.copy()
    mirrored[:, 1] *= -1
    assert np.max(np.abs(g.wall_distance(x) - g.wall_distance(mirrored))) < 1e-14
    assert np.isfinite(g.wall_distance(x)).all()
    assert not g.contains(np.array([[-.02, 0, 0], [.02, 0, 0], [0, 0, .01]])).any()


def test_classifier_first_crossing_and_permanent_particle_identity():
    g = geometry()
    c = BranchClassifier(g, [73, 19, 88])
    a, b = g.directions.values()
    old = np.array([a*.009, b*.009, a*.011])
    new = np.array([a*.011, b*.011, a*.009])
    velocity = (new-old)/.2
    events = c.observe([73, 19, 88], old, new, velocity, velocity, 1., 1.2)
    assert len(events) == 2
    assert c.assignment == {73: Branch.BRANCH_A, 19: Branch.BRANCH_B, 88: Branch.UNASSIGNED}
    assert abs(events[0]["crossing_time_s"] - 1.1000001) < 1e-12
    assert np.allclose(events[0]["position_m"], a*(.010+1e-9), atol=1e-15)
    assert not c.observe([73], (b*.009)[None], (b*.011)[None], b[None], b[None], 2, 3)
    assert c.assignment[73] == Branch.BRANCH_A


def test_classifier_rejects_missed_disk_and_endpoint_guess():
    g = geometry()
    c = BranchClassifier(g, [0])
    a = g.directions[Branch.BRANCH_A]
    old, new = a*.009+[0,0,.002], a*.011+[0,0,.002]
    assert not c.observe([0], old[None], new[None], a[None], a[None], 0, 1)
    assert c.summary()["N_unassigned"] == 1
    with pytest.raises(ValueError):
        BranchClassifier(g, [4, 4])


def test_projection_and_geometric_wall_slip():
    g = geometry()
    x = np.array([[-.006, .0015, 0.]])
    radius = np.array([1.78e-6])
    feasible, hit = g.project(x, radius)
    assert hit.all() and g.contains(feasible, radius-1e-12).all()
    velocity = g.constrain_velocity(feasible, radius, np.array([[.003, .004, 0.]]))
    assert velocity[0, 0] == pytest.approx(.003)
    assert abs(velocity[0, 1]) < 1e-9
