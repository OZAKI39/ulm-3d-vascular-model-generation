"""Final regression and the original immutable Stage 3 evidence manifest."""
import ast
import json
import subprocess
from scripts.stage4.common import ROOT,new_run,require,sha,finish


def main():
    baseline = require("audit")
    out = new_run("audit/final",dict(baseline_run=baseline["run"]))
    protected = json.loads((ROOT / baseline["run"] / "STAGE3_BASELINE_FILES.json").read_text())
    changed = [name for name,digest in protected.items() if not (ROOT/name).is_file() or sha(ROOT/name)!=digest]
    assert subprocess.check_output(["git","rev-parse","stage3-minimal-validated^{}"],text=True).strip()==baseline["baseline_commit"]
    checks = []
    for name,command in [("regression",[".venv/bin/pytest","-q","--junitxml="+str(out/"pytest.xml")]),
                         ("archive",[".venv/bin/pytest","-q","-m","deprecated_reference"]),
                         ("ruff",[".venv/bin/ruff","check","src","tests","scripts","validation/history_force_sensitivity","validation/history_branch_robustness"])]:
        result = subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
        (out / (name+".log")).write_text(result.stdout+result.stderr)
        checks.append(dict(name=name,returncode=result.returncode,output=(result.stdout+result.stderr)[-1200:]))
    forbidden = []
    for path in (ROOT/"src").rglob("*.py"):
        for node in ast.walk(ast.parse(path.read_text())):
            names = [node.module or ""] if isinstance(node,ast.ImportFrom) else [x.name for x in node.names] if isinstance(node,ast.Import) else []
            if any("history_branch_robustness" in name or "history_force_sensitivity" in name for name in names):
                forbidden.append(str(path.relative_to(ROOT)))
    finish(out,dict(status="PASS" if not changed and not forbidden and all(c["returncode"]==0 for c in checks) else "FAIL",
                    protected_files=len(protected),changed=changed,production_history_imports=forbidden,checks=checks,
                    stage3_acceptance_sha256=sha(ROOT/"PHYSICS_ACCEPTANCE.json"),
                    baseline_commit=baseline["baseline_commit"],scope="Regression and evidence preservation; numerical tests do not establish physical calibration"))


if __name__=="__main__":
    main()
