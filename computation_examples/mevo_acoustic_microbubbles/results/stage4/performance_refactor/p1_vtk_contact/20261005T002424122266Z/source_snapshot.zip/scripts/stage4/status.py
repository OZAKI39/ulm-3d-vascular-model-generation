"""Read saved Stage 4 progress without opening active HDF5 files or starting jobs."""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
KINDS = {"H": "statistics/paired_runs", "I": "primary_secondary",
         "J": "convergence", "K": "history_branch", "audit": "audit/final", "report": "report"}


def read(path):
    return json.loads(path.read_text()) if path.is_file() else None


def snapshot():
    base = ROOT / "results/stage4"
    execution = read(base / "CURRENT_EXECUTION_STATE.json")
    result = dict(execution=execution, scope="Saved progress only; RUNNING is not a live process check.")
    if not execution or execution.get("status") != "RUNNING":
        return result
    kind = KINDS.get(execution.get("stage"))
    if not kind:
        return result
    runs = sorted(p.parent for p in (base / kind).glob("*/IDENTITY.json"))
    if not runs:
        return result
    folder = runs[-1]
    # Do not present a previous invocation's batch as the currently queued work.
    if folder.name < Path(execution["execution"]).name:
        result["batch"] = "No batch created in this invocation yet"
        return result
    rows = read(folder / "ROWS.json") or []
    active = []
    failure_records = []
    for path in sorted(folder.glob("*/EXECUTION_FAILURE.json")):
        try:
            record = read(path)
        except json.JSONDecodeError:
            record = dict(read_warning="Worker failure JSON was being written; retry this read-only command.")
        failure_records.append(dict(run=str(path.parent.relative_to(ROOT)),record=record))
    now = datetime.now(timezone.utc).timestamp()
    for path in sorted(folder.glob("*/PROGRESS.json")):
        if (path.parent / "BRANCH_METRICS.json").exists():
            continue
        try:
            progress = read(path) or {}
        except json.JSONDecodeError:
            progress = dict(read_warning="Worker progress JSON was being rewritten; retry this read-only command.")
        active.append(dict(run=str(path.parent.relative_to(ROOT)),
                           time_s=progress.get("time_s"),active_particles=progress.get("active_particles"),
                           elapsed_s=progress.get("elapsed_s"),
                           progress_age_s=round(max(0.,now-path.stat().st_mtime),1),
                           read_warning=progress.get("read_warning")))
    result.update(batch=str(folder.relative_to(ROOT)),completed_case_count=len(rows),
                  completed_cases=[{k:row[k] for k in ["case","seed","N_A","N_B","N_unassigned","N_wall_loss"]} for row in rows],
                  unfinished_saved_progress=active,failed_cases=read(folder/"FAILED_CASES.json") or [],
                  worker_failure_records=failure_records,
                  batch_summary=read(folder/"SUMMARY.json"))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json",action="store_true",help="Print complete saved evidence pointers as JSON")
    args = parser.parse_args()
    state = snapshot()
    if args.json:
        print(json.dumps(state,indent=2,allow_nan=False))
        return
    current = state["execution"] or {}
    print("Recorded execution:",current.get("status","NOT_STARTED"),current.get("stage",""),current.get("script",""))
    if "batch" in state:
        print("Batch:",state["batch"])
        print("Completed cases:",state.get("completed_case_count",0))
    for row in state.get("unfinished_saved_progress",[]):
        print(Path(row["run"]).name,"time_s=",row["time_s"],"active=",row["active_particles"],
              "elapsed_s=",row["elapsed_s"],"progress_age_s=",row["progress_age_s"])
        if row["read_warning"]:
            print(row["read_warning"])
    for row in state.get("failed_cases",[]):
        print("FAILED:",json.dumps(row))
    for row in state.get("worker_failure_records",[]):
        print("WORKER_FAILURE:",json.dumps(row))
    print(state["scope"])


if __name__ == "__main__":
    main()
