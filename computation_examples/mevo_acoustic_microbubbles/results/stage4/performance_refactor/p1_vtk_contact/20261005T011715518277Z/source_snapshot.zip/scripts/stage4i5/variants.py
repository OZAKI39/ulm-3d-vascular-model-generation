"""Explicit opt-in candidates; no production default changes before validation."""
import pyvista as pv

import mevo_mb.bubbles.contact as contact
from mevo_mb.bubbles.neighbor_cache import ContactNeighborCache
from mevo_mb.coupling.wall_backends import ExactCoordinateWallCache, PersistentVTKWallBackend

ORIGINAL_CANDIDATES = contact.contact_candidates


def install_variant(tracker, backend):
    options = {
        "P1_exact_cache": (True,False,False),
        "P1_neighbor": (False,True,False),
        "P1_combined": (True,True,False),
        "P1_static": (True,False,True),
        "P2_warp": (True,False,False),
    }
    if backend not in options:
        raise ValueError("Unknown candidate backend: "+backend)
    cache,neighbor,static=options[backend]
    info=dict(backend=backend,physics_changed=False)
    if cache:
        wall=PersistentVTKWallBackend(pv.read(tracker.config["geometry"]["mesh_surface"])) if static else None
        if backend=="P2_warp":
            from mevo_mb.coupling.warp_wall import WarpWallBackend
            wall=WarpWallBackend(pv.read(tracker.config["geometry"]["mesh_surface"]))
        exact=ExactCoordinateWallCache(tracker.cylinder,query_backend=wall)
        tracker.cylinder.level_and_gradient=exact.level_and_gradient
        tracker._i5_wall_cache=exact
        tracker._i5_wall_backend=wall
    if neighbor:
        candidates=ContactNeighborCache(4*tracker.p["size_distribution"]["radius_m"],tracker.p["contact_tolerance_m"])
        tracker._i5_neighbor_cache=candidates

        def cached(x,radii,gap_m=0.,backend="brute",timings=None):
            if backend!="ckdtree":
                return ORIGINAL_CANDIDATES(x,radii,gap_m,backend,timings)
            return candidates.candidates(x,radii,gap_m,timings)

        contact.contact_candidates=cached
        tracker._i5_cleanup=lambda:setattr(contact,"contact_candidates",ORIGINAL_CANDIDATES)
    return info
