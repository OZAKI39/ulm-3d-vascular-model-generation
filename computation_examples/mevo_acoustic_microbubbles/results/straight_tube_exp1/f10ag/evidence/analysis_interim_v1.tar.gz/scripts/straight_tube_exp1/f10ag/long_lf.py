"""Reuse real shorter prefixes; only new 250 ms physics is integrated."""
import time
import numpy as np,h5py
from .common import *
from .experiment import batch

def main():
 begin=time.perf_counter();verify();assert (BASE/'HF250_RESULTS.json').exists();run,slow,_,_=bind();rows=[];checkpoints=[];tasks=[]
 for state in ['random_0','mid']:
  r=read(BASE/'lf'/('long150_'+state)/'SUMMARY.json');rows.append(r)
  with h5py.File(BASE/r['trajectory_path']) as h:
   times=h['time_s'][:]
   for T in [.05,.075,.1,.15]:
    ix=min(max(np.searchsorted(times,T+1e-13,side='right')-1,0),len(times)-1);x=h['positions_m'][ix]
    checkpoints.append(dict(state=state,target_checkpoint_s=T,actual_accepted_time_s=float(times[ix]),raw_node_index=int(ix),source_trajectory=r['trajectory_path'],source_sha256=r['trajectory_sha256'],minimum_wall_gap_m=float((.0008-np.linalg.norm(x[:,1:],axis=1)-R).min()),scope='Actual accepted prefix of completed 150 ms LF; not a separately rerun trajectory, no padding or interpolation'))
  existing=BASE/'lf'/('long250_'+state)/'SUMMARY.json'
  if existing.exists():rows.append(read(existing))
  else:tasks.append(run.task('ladder_'+state+'_250',state='AG32_'+state,duration=.25))
 write(BASE/'LF_LADDER_PLAN.json',dict(checkpoints=checkpoints,new_tasks=tasks,reason='Reuse already completed matching fixed-action trajectories; compute only genuinely new windows',identity=identity()));rows+=batch(tasks,kinds=('LF',),workers=1)
 write(BASE/'LF_LADDER_RESULTS.json',dict(rows=rows,checkpoints=checkpoints,wall_s=time.perf_counter()-begin,identity=identity()))
 print('LF_LADDER_DONE',time.perf_counter()-begin,flush=True)
if __name__=='__main__':main()
