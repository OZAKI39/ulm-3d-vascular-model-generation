"""Compact local research handoff and manifests; never rewrite historical results."""
from pathlib import Path
import json,shutil,difflib,re,subprocess
from .common import *
from .remote import SERVER,call

def main():
 sci=read(BASE/'SCIENTIFIC_RESULTS.json');stage=[]
 rpc="import xmlrpc.client,json;from supervisor.xmlrpc import SupervisorTransport;s=xmlrpc.client.ServerProxy('http://localhost',transport=SupervisorTransport(None,None,'unix:///var/run/supervisor.sock'));print(json.dumps([{k:r[k] for k in ['name','statename','start','stop','now','exitstatus']} for r in s.supervisor.getAllProcessInfo() if r['name'].startswith('mevo_f10ag_')]))"
 jobs=json.loads(call('import subprocess\nprint(subprocess.check_output(["/usr/bin/python3","-c",'+repr(rpc)+'],text=True))'))
 write(BASE/'evidence/SUPERVISOR_FINAL_PROCESS_INFO.json',jobs)
 science_jobs=[r for r in jobs if not any(v in r['name'] for v in ['analysis','resources','seal'])];analysis_jobs=[r for r in jobs if 'analysis' in r['name']]
 assert all(r['statename']!='RUNNING' for r in science_jobs+analysis_jobs),'Scientific work is still running'
 science_job_wall=sum(r['stop']-r['start'] for r in science_jobs);analysis_job_wall=sum(r['stop']-r['start'] for r in analysis_jobs)
 assert science_job_wall<=6000,'Registered scientific wall budget exceeded'

 for name,key in [('BASELINE_RESULTS.json','wall_s'),('STATIC_RESULTS.json','wall_s'),('SINGLE_RESULTS.json','wall_s'),('ROTATION_STATIC.json','wall_s'),('F1_SHADOW_RESULTS.json','wall_s'),('EXPERIMENT_DONE.json','wall_s'),('HF250_RESULTS.json','wall_s'),('LF_LADDER_RESULTS.json','wall_s')]:
  if (BASE/name).exists():stage.append(dict(file=name,wall_s=read(BASE/name)[key]))
 # V1 pilot produced the successful raw trajectories but exited during comparison.
 # Retried orchestration reused those trajectories; preserve their separate cost.
 pilot_h=[read(p) for p in (BASE/'hf').glob('pilot*/SUMMARY.json')];pilot_l=[read(p) for p in (BASE/'lf').glob('pilot*/SUMMARY.json')];pilot_service=sum(r['task_wall_s'] for r in pilot_h)+sum(r['wall_s'] for r in pilot_l)
 write(BASE/'COMPUTE_COST.json',dict(supervisor_science_job_wall_sum_s=science_job_wall,supervisor_analysis_job_wall_sum_s=analysis_job_wall,scientific_budget_s=6000,budget_pass=science_job_wall<=6000,first_to_last_science_elapsed_s=max(r['stop'] for r in science_jobs)-min(r['start'] for r in science_jobs),supervisor_timing_scope='Integer-second process durations including failed attempts; overlapping job durations are sums, not elapsed campaign time. Baseline includes internal audits.',scientific_stage_wall_sum_s=sum(r['wall_s'] for r in stage),stages=stage,initial_pilot_service_time_s=pilot_service,note='Initial pilot ran before failed timestamp comparison; its summed service time is reported separately, not falsely treated as serial elapsed. Stage sums may overlap; total task service time is a different quantity.',HF_task_service_s=sum(r['wall_s'] for r in sci['rows'] if r['kind']=='HF'),LF_task_service_s=sum(r['wall_s'] for r in sci['rows'] if r['kind']=='LF'),analysis_audit_s=analysis_job_wall,last_incremental_analysis_s=sci['wall_s'],figures_s=read(BASE/'figures/MANIFEST.json')['wall_s'],videos_s=read(BASE/'videos/MANIFEST.json')['wall_s'],identity=identity()))
 doc=Path('/home/lzy/projects/microbubble_aggregation.md');backup=doc.with_name(doc.name+'.bak_F10AG_20261019');ev=BASE/'evidence'
 if not backup.exists():shutil.copy2(doc,backup)
 before=backup.read_text();marker='## 2.9 F10AG：三维捕获、长时间条带与旋转机制'
 section=f'''\n\n{marker}\n\n本轮在F10AF完整物理基础上复现冻结基准，检查三维漂移Jacobian、局部捕获时间、完整多泡条带和正反相位旋转。中央X恢复位置间距约304.487 µm；存在局部三维稳定点，但Y/Z恢复远弱于X方向。\n\n- 完整高保真最长{sci['max_HF_time_s']*1000:.0f} ms；低保真最长{sci['max_LF_time_s']*1000:.0f} ms；通过逐ID和带归属配对的窗口最多{sci['max_paired_admitted_s']*1000:.0f} ms。\n- 162个独立单泡起点完成250 ms捕获诊断；近带捕获不代表从全局随机云形成条带。\n- 三个独立随机云、预置近/中/远带群及预置环用于不同验证，全部失败和右删失记录保留。\n- 正式条带、持续可反向群体旋转及多保真AI准入以FINAL_GATE为准；没有加入声流、浮力或新的泡径响应。\n- 当前结果保持EXPLORATORY、PHYSICS_UNCALIBRATED、training_ready=false。\n\n代码：`{ROOT}`。分支：`dev/f10ag-3d-capture-longtime-20261019`。\n\n[完整科研报告]({BASE}/F10AG_DEVELOPMENT_REPORT.md) · [科学准入]({BASE}/FINAL_GATE.json) · [图表]({BASE}/figures) · [视频]({BASE}/videos)\n\n![F10AG真实多泡条带检验]({BASE}/figures/Fig_F10AG_07_multibubble_stripe_dynamics.png)\n\n[三维真实捕获视频]({BASE}/videos/Video_F10AG_1_3d_acoustic_capture.mp4)\n'''
 if marker not in doc.read_text():doc.write_text(doc.read_text()+section)
 after=doc.read_text();(ev/'PROGRESS_BEFORE.md').write_text(before);(ev/'PROGRESS_AFTER.md').write_text(after);(ev/'PROGRESS.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before',tofile='after')));heads=lambda t:re.findall(r'^#{1,6} .+$',t,re.M);assert all(h in heads(after) for h in heads(before));write(ev/'PROGRESS_AUDIT.json',dict(before_sha256=sha(backup),after_sha256=sha(doc),old_headings_preserved=True,backup=str(backup)))
 # Source protection checked again at finalization; no historical scientific edits.
 available={p:h for p,h in read(BASE/'PREREGISTRATION.json')['protected_sha256'].items() if (ROOT/p).exists()};assert all(sha(ROOT/p)==h for p,h in available.items());assert read(BASE/'FINAL_EXECUTION_SEAL.json')['protected_inputs_pass'];diff=subprocess.check_output(['git','diff','4eb54462b91cfc9d81dc08d8edd6803175724523','--','src','scripts/straight_tube_exp1/f10aa','scripts/straight_tube_exp1/f10af'],cwd=ROOT,text=True);assert not diff;write(ev/'OLD_PHYSICS_PRESERVATION.json',dict(unchanged=True,base_commit='4eb54462b91cfc9d81dc08d8edd6803175724523',identity=identity()))
 raw=json.loads(call('from pathlib import Path\nimport hashlib,json\nb=Path('+repr(SERVER+'/results/straight_tube_exp1/f10ag')+')\nrr=[]\nfor p in b.glob("hf/*/runs/*/trajectory.h5"):\n h=hashlib.sha256()\n with p.open("rb") as f:\n  for z in iter(lambda:f.read(4*1024*1024),b""):h.update(z)\n rr.append(dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest()))\nprint(json.dumps(rr))'))
 input_code='from pathlib import Path\nimport json\nb=Path('+repr(SERVER+'/results/straight_tube_exp1/f10ag')+')\nseal=json.loads((b/"FINAL_EXECUTION_SEAL.json").read_text());root=Path(seal["execution_root"]);reg=json.loads((b/"PREREGISTRATION.json").read_text())\nprint(json.dumps([dict(relative_path=p,absolute_path=str((root/p).resolve()),bytes=(root/p).stat().st_size,sha256=v) for p,v in reg["protected_sha256"].items() if p.startswith("results/")]))'
 inputs=json.loads(call(input_code))
 write(BASE/'REMOTE_RAW_INDEX.json',dict(files=raw,protected_inputs=inputs,server=SERVER,recovery='Use rsync -av with ssh -i /home/lzy/.ssh/vast_step3b_ed25519 -p 15283. Preserve recorded relative input layout under a NEW checkout; absolute server locations and SHA-256 are enumerated. Restore AF fields and matched APECSS inputs before any replay. Do not overwrite historical outputs.',identity=identity()));manifest()
def manifest():
 files={str(p.relative_to(BASE)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in BASE.rglob('*') if p.is_file() and not p.is_symlink() and p.name not in ['INPUT_OUTPUT_SHA256.json','LOCAL_RECEIPT.json'] and not p.name.endswith('.tar.gz') and '/fields/' not in str(p)}
 source={str(p.relative_to(ROOT)):sha(p) for folder in ['scripts/straight_tube_exp1/f10ag','configs/straight_tube_exp1/f10ag','tests/f10ag'] for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in str(p)}
 write(BASE/'INPUT_OUTPUT_SHA256.json',dict(files=files,source_sha256=source,protected_input_manifest='PREREGISTRATION.json',identity=identity()))
if __name__=='__main__':main()
