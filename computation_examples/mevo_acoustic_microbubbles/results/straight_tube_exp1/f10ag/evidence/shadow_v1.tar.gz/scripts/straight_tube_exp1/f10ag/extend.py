"""Optional 250 ms HF capture confirmation, cost-admitted after actual 150 ms."""
import time
from .common import *
from .experiment import batch
from .paired import compare

def main():
 begin=time.perf_counter();verify();assert (BASE/'EXPERIMENT_DONE.json').exists();run,slow,_,_=bind();budget=read(BASE/'BUDGET_FREEZE.json');used=read(BASE/'EXPERIMENT_DONE.json')['wall_s']+budget['baseline_wall_s'];tasks=[];decisions=[]
 for state in ['near','random_0']:
  r=read(BASE/'hf'/('long150_'+state)/'SUMMARY.json');prediction=r['task_wall_s']*.25/.15*1.1;allow=r['status']=='PASS' and prediction<540 and used+prediction<4500
  decisions.append(dict(state=state,predicted_task_wall_s=prediction,admitted=allow))
  if allow:tasks.append(run.task('long250_'+state,state='AG32_'+state,duration=.25));used+=prediction
 write(BASE/'HF250_PLAN.json',dict(tasks=tasks,decisions=decisions,identity=identity()));rows=batch(tasks,kinds=('HF','LF'),workers=2) if tasks else [];pairs=[compare(t) for t in tasks]
 # Budget-controlled DT reference if longest refinements were unaffordable.
 prior=read(BASE/'REFINEMENT_RESULTS.json')['rows'];refs=[]
 if not any(r['status']=='PASS' and r['task'].get('variant')=='DT05' for r in prior):
  refs=[run.task('dtcheck50',state='AG32_random_0',duration=.05),run.task('dtcheck50_DT05',state='AG32_random_0',duration=.05,variant='DT05'),run.task('dtcheck50_FINE',state='AG32_random_0',duration=.05,variant='FINE')]
 write(BASE/'DT_FALLBACK_PLAN.json',dict(tasks=refs,identity=identity()));rr=batch(refs,kinds=('HF',),workers=2) if refs else []
 write(BASE/'HF250_RESULTS.json',dict(rows=rows,paired=pairs,extra_refinements=rr,wall_s=time.perf_counter()-begin,identity=identity()))
if __name__=='__main__':main()
