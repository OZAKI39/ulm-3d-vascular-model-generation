import unittest
import numpy as np
from scripts.straight_tube_exp1.f10ag.capture import capture
class CaptureTests(unittest.TestCase):
 def test_right_censor_does_not_extrapolate(self):
  t=np.linspace(0,.02,21);x=np.zeros((21,1,3));x[:,0,0]=40e-6
  r=capture(t,x,[0])[0];self.assertTrue(r['right_censored']);self.assertIsNone(r['first_entry_s'])
 def test_hold_and_reexit(self):
  t=np.linspace(0,.03,31);x=np.zeros((31,1,3));x[:,0,0]=40e-6;x[5:21,0,0]=10e-6
  r=capture(t,x,[0])[0];self.assertFalse(r['right_censored']);self.assertTrue(r['reexit']);self.assertAlmostEqual(r['first_held_entry_s'],.005)
 def test_short_entry_is_not_capture(self):
  t=np.linspace(0,.02,21);x=np.zeros((21,1,3));x[:,0,0]=40e-6;x[-4:,0,0]=10e-6
  r=capture(t,x,[0])[0];self.assertTrue(r['right_censored']);self.assertIsNotNone(r['first_entry_s'])
 def test_band_hopping_breaks_hold(self):
  t=np.arange(11)*.001;x=np.zeros((11,1,3));x[5:,0,0]=100e-6
  r=capture(t,x,[0,100e-6],hold=.008)[0];self.assertTrue(r['right_censored'])
 def test_initial_capture_is_labeled_zero(self):
  t=np.linspace(0,.02,21);x=np.zeros((21,1,3));r=capture(t,x,[0])[0];self.assertEqual(r['first_entry_s'],0.);self.assertFalse(r['right_censored'])
if __name__=='__main__':unittest.main()
