"""Increasing real LF integrations; only paired windows receive numeric admission."""
import time
from .common import *
from .experiment import batch

def main():
 begin=time.perf_counter();verify();assert (BASE/'EXPERIMENT_DONE.json').exists();run,slow,_,paired=bind();rows=[]
 for T in [.05,.075,.1,.15,.25]:
  todo=[]
  for state in ['AG32_random_0','AG32_mid']:
   if any(r['status']!='PASS' and r['task']['state']==state for r in rows):continue
   t=run.task(f'ladder_{state}_{round(T*1000)}',state=state,duration=T);todo.append(t)
  write(BASE/f'LF_LADDER_PLAN_{round(T*1000)}.json',dict(tasks=todo,identity=identity()));rows+=batch(todo,kinds=('LF',),workers=2)
  write(BASE/'LF_LADDER_RESULTS.json',dict(rows=rows,wall_s=time.perf_counter()-begin,identity=identity()))
 print('LF_LADDER_DONE',time.perf_counter()-begin,flush=True)
if __name__=='__main__':main()
