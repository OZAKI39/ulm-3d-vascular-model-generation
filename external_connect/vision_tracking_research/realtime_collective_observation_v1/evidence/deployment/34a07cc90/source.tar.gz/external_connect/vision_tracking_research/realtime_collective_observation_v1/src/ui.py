"""One Qt UI shared by replay and LIVE. Screen recordings capture these widgets."""
import time,queue,threading
from pathlib import Path
import numpy as np,cv2,av
from PySide6 import QtWidgets as W,QtCore as C,QtGui as G
from ycommon import ROOT,dump
from pipeline import Pipeline
class Canvas(W.QWidget):
 def __init__(self):super().__init__();self.setMinimumSize(700,550);self.snap=None;self.layers={};self.editing=False;self.points=[];self.image_rect=None
 def mousePressEvent(self,e):
  if self.editing and self.image_rect:
   x,y,w,h,iw,ih=self.image_rect;p=e.position()
   if x<=p.x()<x+w and y<=p.y()<y+h:self.points.append([(p.x()-x)*iw/w,(p.y()-y)*ih/h]);self.update()
 def paintEvent(self,e):
  painter=G.QPainter(self);painter.fillRect(self.rect(),G.QColor('#101820'));s=self.snap
  if not s or not s['raw']:painter.setPen(G.QColor('white'));painter.drawText(self.rect(),C.Qt.AlignCenter,'Waiting for source — no automatic fallback');return
  p=s.get('display_packet') or s['raw'];a=np.ascontiguousarray(p.image);h,w=a.shape[:2]
  fmt=G.QImage.Format_Grayscale8 if a.ndim==2 else G.QImage.Format_BGR888;im=G.QImage(a.data,w,h,a.strides[0],fmt)
  scale=min(self.width()/w,self.height()/h);ox=(self.width()-w*scale)/2;oy=(self.height()-h*scale)/2;self.image_rect=(ox,oy,w*scale,h*scale,w,h)
  painter.translate(ox,oy);painter.scale(scale,scale);painter.drawImage(0,0,im)
  state=s['state'];valid=s['valid']
  if state and valid and state.get('geometry') and p.frame_id==state['frame_id']:
   g=state['geometry'];x,y,_,_=g['crop_xywh']
   if self.layers.get('Mask',True):
    painter.setPen(G.QPen(G.QColor('#55dfd0'),2/scale));painter.drawPolygon(G.QPolygonF([C.QPointF(*v) for v in g['channel_polygon']]))
    painter.setBrush(G.QColor(30,30,40,80))
    for poly in g['excluded_polygons']:painter.drawPolygon(G.QPolygonF([C.QPointF(*v) for v in poly]))
    painter.setBrush(C.Qt.NoBrush)
   if self.layers.get('Candidates',True):
    painter.setPen(G.QPen(G.QColor('#73e9fa'),1.2/scale))
    for px,py in state['candidates']:painter.drawEllipse(C.QPointF(px+x,py+y),4,4)
   if self.layers.get('Validity',False):
    painter.setPen(G.QPen(G.QColor(245,195,90,90),1/scale))
    for (px,py),ok in zip(state['window_grid_xy'],state['window_valid']):
     if not ok:painter.drawPoint(C.QPointF(px+x,py+y))
   if self.layers.get('PIV',True):
    painter.setPen(G.QPen(G.QColor('#f0e29b'),1.5/scale))
    for px,py,u,v in state['vectors'][::2]:
     dx,dy=np.array([u,v])*.10;norm=np.hypot(dx,dy)
     if norm>35:dx*=35/norm;dy*=35/norm
     painter.drawLine(C.QPointF(px+x,py+y),C.QPointF(px+x+dx,py+y+dy))
   if self.layers.get('Regions',True) and state.get('aggregation'):
    painter.setPen(G.QPen(G.QColor('#e3a6d8'),1.3/scale))
    for c in state['aggregation']['clusters']:
     a,b,d,f=c['extent'];painter.drawRect(C.QRectF(a+x,b+y,d-a,f-b))
     if self.layers.get('Shape',True):
      px,py=c['center'];r=c['rg_px'];painter.drawEllipse(C.QPointF(px+x,py+y),r,r)
  if self.points:
   painter.setPen(G.QPen(G.QColor('#ffcc66'),3/scale));painter.drawPolyline(G.QPolygonF([C.QPointF(*v) for v in self.points]))
  painter.resetTransform()
  if not valid:
   painter.fillRect(10,10,self.width()-20,36,G.QColor(50,20,20,210));painter.setPen(G.QColor('#ffc27b'));painter.drawText(20,34,s['status']+' — motion / trend invalid')
class Curves(W.QWidget):
 def __init__(self):super().__init__();self.setMinimumHeight(210);self.rows=[];self.events=[]
 def paintEvent(self,e):
  p=G.QPainter(self);p.fillRect(self.rect(),G.QColor('#182430'));labels=['Count','Density','NN / px','Rg / px','Radial px/s','Valid update'];cols=['#73e9fa','#a5d6a7','#ce93d8','#ffd180','#ef9a9a','#90caf9']
  for j,name in enumerate(labels):
   x=(j%3)*self.width()/3;y=(j//3)*self.height()/2;w=self.width()/3;h=self.height()/2;p.setPen(G.QColor(cols[j]));p.drawText(int(x+8),int(y+18),name)
   vals=[r[j+3] for r in self.rows[-150:]]
   if len(vals)>2:
    finite=[v for v in vals if v is not None and np.isfinite(v)];lo=min(finite) if finite else 0;hi=max(finite) if finite else 1
    path=G.QPainterPath();started=False
    for k,v in enumerate(vals):
     if v is None:started=False;continue
     pt=C.QPointF(x+8+k*(w-16)/(len(vals)-1),y+h-10-(v-lo)/max(hi-lo,1e-6)*(h-38))
     if started:path.lineTo(pt)
     else:path.moveTo(pt);started=True
    p.drawPath(path);p.drawText(int(x+w-80),int(y+18),f'{vals[-1]:.2f}' if vals[-1] is not None else 'null')
  if self.events:p.setPen(G.QColor('#ffc27b'));p.drawText(10,self.height()-2,f'Event markers: {len(self.events)} (record only; host time)')
class ScreenRecorder:
 def __init__(self,path):self.path=path;self.q=queue.Queue(8);self.done=threading.Event();self.dropped=0;self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
 def submit(self,image,t):
  a=image.convertToFormat(G.QImage.Format_RGB888);arr=np.frombuffer(a.bits(),np.uint8,count=a.sizeInBytes()).reshape(a.height(),a.bytesPerLine())[:,:a.width()*3].reshape(a.height(),a.width(),3).copy()
  try:self.q.put_nowait((arr,t))
  except queue.Full:self.dropped+=1
 def run(self):
  from fractions import Fraction
  out=av.open(str(self.path),'w');stream=None
  try:
   while not self.done.is_set() or not self.q.empty():
    try:a,t=self.q.get(timeout=.05)
    except queue.Empty:continue
    if stream is None:
     stream=out.add_stream('libx264',rate=20);stream.width=a.shape[1]//2*2;stream.height=a.shape[0]//2*2;stream.pix_fmt='yuv420p';stream.time_base=Fraction(1,1000000);stream.options={'crf':'22','preset':'ultrafast','threads':'2'}
    f=av.VideoFrame.from_ndarray(a[:stream.height,:stream.width],format='rgb24');f.pts=round(t*1e6);f.time_base=Fraction(1,1000000)
    for packet in stream.encode(f):out.mux(packet)
   if stream:
    for packet in stream.encode():out.mux(packet)
  finally:out.close()
 def close(self):self.done.set();self.thread.join(15)
class Window(W.QMainWindow):
 def __init__(self,cfg,output,auto=False,seconds=None,capture=None):
  super().__init__();self.cfg=cfg;self.output=Path(output);self.pipe=None;self.record=None;self.started=time.monotonic();self.elapsed_limit=seconds;self.capture=capture;self.metrics_last=None;self.saved_preview=False
  self.setWindowTitle('F10Y · Chronos collective observation');self.resize(1480,1000)
  self.setStyleSheet('QWidget{background:#15212d;color:#e9eff4;font-size:13px;} QPushButton,QComboBox,QLineEdit{background:#263a4b;border:1px solid #4c657b;border-radius:4px;padding:7px;} QPushButton:hover{background:#36556b;} QGroupBox{border:1px solid #3d5366;margin-top:12px;padding-top:12px;} QGroupBox::title{subcontrol-origin:margin;left:10px;}')
  central=W.QWidget();self.setCentralWidget(central);grid=W.QGridLayout(central);self.canvas=Canvas();grid.addWidget(self.canvas,0,0);side=W.QWidget();side.setFixedWidth(380);form=W.QVBoxLayout(side);grid.addWidget(side,0,1);self.curves=Curves();grid.addWidget(self.curves,1,0,1,2);grid.setRowStretch(0,1)
  title=W.QLabel('CHRONOS | OBSERVATION\n2D visible trends · no hardware control');title.setStyleSheet('font-size:17px;font-weight:600');form.addWidget(title)
  group=W.QGroupBox('1  Source and session');g=W.QGridLayout(group);self.mode=W.QComboBox();self.mode.addItems(['REALTIME_REPLAY','LIVE_CAMERA']);self.mode.setCurrentText(cfg['source_mode']);g.addWidget(self.mode,0,0,1,2)
  self.speed=W.QComboBox();self.speed.addItems(['0.5','1.0','2.0']);self.speed.setCurrentText(str(cfg['speed']));self.loop=W.QCheckBox('Loop (reset session)');self.loop.setChecked(cfg['loop']);g.addWidget(self.speed,1,0);g.addWidget(self.loop,1,1)
  self.buttons={}
  for i,(name,fn) in enumerate([('Start',self.start),('Stop',self.stop),('Pause',self.pause),('Resume',self.resume),('Reconnect',self.reconnect),('Open records',self.open_records)]):
   b=W.QPushButton(name);b.clicked.connect(fn);g.addWidget(b,2+i//2,i%2);self.buttons[name]=b
  form.addWidget(group)
  group=W.QGroupBox('2  Image layers and LIVE geometry');g=W.QGridLayout(group);self.checks={}
  for i,name in enumerate(['Candidates','PIV','Mask','Regions','Shape','Validity','Curves']):
   b=W.QCheckBox(name);b.setChecked(name!='Validity');self.checks[name]=b;g.addWidget(b,i//2,i%2)
  for row,name,fn in [(4,'Draw LIVE mask',self.draw_mask),(4,'Save verified mask',self.save_mask),(5,'Load LIVE geometry',self.load_mask)]:
   b=W.QPushButton(name);b.clicked.connect(fn);g.addWidget(b,row,0 if name!='Save verified mask' else 1)
  form.addWidget(group)
  group=W.QGroupBox('3  PZT event annotation — no output');g=W.QGridLayout(group);self.event_source=W.QComboBox();self.event_source.addItems(['SIMULATED_EVENT','MANUAL_ANNOTATION']);g.addWidget(self.event_source,0,0,1,2);self.channel=W.QComboBox();self.channel.addItems(['ALL','X+','X-','Y+','Y-']);g.addWidget(self.channel,1,0,1,2);self.note=W.QLineEdit();self.note.setPlaceholderText('Conditions / event note');g.addWidget(self.note,2,0,1,2)
  for i,state in enumerate(['ON','OFF']):
   b=W.QPushButton('Mark '+state);b.clicked.connect(lambda _,s=state:self.mark_event(s));g.addWidget(b,3,i)
  form.addWidget(group);self.info=W.QLabel('STOPPED');self.info.setWordWrap(True);self.info.setMinimumHeight(200);form.addWidget(self.info);form.addStretch()
  self.timer=C.QTimer(self);self.timer.timeout.connect(self.tick);self.timer.start(round(1000/cfg['ui_hz']))
  if auto:C.QTimer.singleShot(100,self.start)
 def start(self):
  if self.pipe and self.pipe.worker and self.pipe.worker.is_alive():return
  self.cfg.update(source_mode=self.mode.currentText(),speed=float(self.speed.currentText()),loop=self.loop.isChecked())
  self.output.mkdir(parents=True,exist_ok=True);self.pipe=Pipeline(self.cfg,self.output/f'session_{time.time_ns()}');self.pipe.start();self.started=time.monotonic()
  if self.capture and self.record is None:self.record=ScreenRecorder(self.capture)
 def stop(self):
  if self.pipe:self.pipe.stop()
 def pause(self):
  if self.pipe and self.cfg['source_mode']=='REALTIME_REPLAY':self.pipe.source.pause()
 def resume(self):
  if self.pipe:self.pipe.source.resume()
 def reconnect(self):self.stop();self.start()
 def open_records(self):G.QDesktopServices.openUrl(C.QUrl.fromLocalFile(str(self.output)))
 def mark_event(self,state):
  if self.pipe:self.pipe.event(state,self.event_source.currentText(),self.channel.currentText(),self.note.text())
 def draw_mask(self):self.canvas.editing=True;self.canvas.points=[];self.info.setText('Click the channel polygon on the raw image, then Save. LIVE only; choose a fixed-wall registration ROI in JSON before scientific output.')
 def save_mask(self):
  if len(self.canvas.points)<3 or not self.pipe or not self.pipe.raw:return
  p=self.pipe.raw
  if p.source_mode!='LIVE_CAMERA':W.QMessageBox.information(self,'LIVE only','The replay mask is frozen. Use LIVE input to define a new geometry.');return
  w,h=p.original_resolution;cfg=dict(image_wh=[w,h],crop_xywh=[0,0,w,h],channel_polygon=self.canvas.points,excluded_polygons=[],minimum_valid_window_fraction=1.,registration_min_response=.08,registration_max_translation_px=6,human_verified=True,source_mode='LIVE_CAMERA',registration_roi=None)
  path=self.output/'live_geometry.json';dump(path,cfg);self.cfg['live_geometry']=str(path);self.canvas.editing=False;self.info.setText('Mask saved. Set fixed-wall registration_roi in this JSON, then reload; motion remains invalid until verified.')
 def load_mask(self):
  path,_=W.QFileDialog.getOpenFileName(self,'Verified LIVE geometry','','JSON (*.json)')
  if path:self.cfg['live_geometry']=path;self.reconnect()
 def tick(self):
  t=time.perf_counter()
  if self.pipe:
   s=self.pipe.snapshot();s['display_packet']=self.pipe.analyzed_packet if s['valid'] else s['raw'];self.canvas.snap=s;self.canvas.layers={k:v.isChecked() for k,v in self.checks.items()};self.curves.setVisible(self.checks['Curves'].isChecked());self.canvas.update()
   p=s['raw'];r=s['state'];a=r.get('aggregation') if r else None;d=a['regions'][0] if a else {};age=s['age_ms'];elapsed=max(time.monotonic()-self.pipe.start_time,.001);key=(p.session_id,p.frame_id) if p else None
   if key and key!=self.pipe.last_ui_key:
    if self.pipe.last_ui_key and key[0]==self.pipe.last_ui_key[0]:self.pipe.counter['ui_skipped']+=max(0,key[1]-self.pipe.last_ui_key[1]-1)
    self.pipe.last_ui_key=key;self.pipe.counter['ui_frames']+=1
   quality=a['status'] if a and s['valid'] else 'NOT_OBSERVABLE';velocity=d.get('mean_velocity') if s['valid'] else None;res=p.original_resolution if p else None
   resource=self.pipe.samples[-1] if self.pipe.samples else {}
   self.info.setText(f"{self.cfg['source_mode']} | {s['status']}\nResolution: {res} | source frame: {p.frame_id if p else '-'}\nAnalyzed frame: {r['frame_id'] if r else '-'} | PTS: {p.source_pts if p else None}\nAge upper bound: {age:.1f} ms\n" .replace('None','unknown')+f"Candidates: {d.get('count','-')} | valid vectors: {r.get('valid_windows',0) if r else 0}\nMean velocity px/s: {velocity}\nTrend: {quality}\nInput / analysis / valid Hz: {self.pipe.counter['bridge_received']/elapsed:.1f} / {self.pipe.counter['processed']/elapsed:.1f} / {self.pipe.counter['fresh_valid']/elapsed:.1f}\nSkipped analysis / UI / recorder: {s['analysis_skipped']} / {self.pipe.counter['ui_skipped']} / {s['recorder_dropped']}\nCPU: {resource.get('cpu_percent',0):.0f}% | RSS: {resource.get('rss_mib',0):.0f} MiB\nBackend: {self.cfg['backend']} | live accuracy NOT VERIFIED") if age is not None else self.info.setText(s['status'])
   self.curves.rows=list(self.pipe.metric_history);self.curves.events=self.pipe.events;self.curves.update();self.pipe.ui_times.append((time.perf_counter()-t)*1000)
   if self.record:self.record.submit(self.grab().toImage(),time.monotonic()-self.started)
   if not self.saved_preview and time.monotonic()-self.started>4:
    self.grab().save(str(self.output/'ui_actual.png'));self.saved_preview=True
   if self.elapsed_limit and time.monotonic()-self.started>=self.elapsed_limit:self.close()
 def closeEvent(self,e):
  self.timer.stop();self.stop()
  if self.record:self.record.close()
  dump(self.output/'ui_summary.json',dict(screen_capture_dropped=self.record.dropped if self.record else 0,software_replay_not_live=self.cfg['source_mode']=='REALTIME_REPLAY',closed=True))
  e.accept()
