"""Bounded acquisition/analysis/recording, lightweight TTL publisher and UI snapshot."""
import threading,time,queue,json,gzip,uuid,traceback
from collections import Counter,deque
from pathlib import Path
import numpy as np,psutil
from ycommon import clean,dump,stats,identity
from protocol import Continuity,LatestSlot
from sources import RecordedVideoFrameSource
from observer import Observer
class Recorder:
 def __init__(self,path,capacity=32):
  self.q=queue.Queue(capacity);self.stop=threading.Event();self.dropped=0;self.written=0;self.times=[];self.error=None;self.path=Path(path);self.thread=threading.Thread(target=self.run,name='state-recorder',daemon=True);self.thread.start()
 def submit(self,x):
  try:self.q.put_nowait(x)
  except queue.Full:self.dropped+=1
 def run(self):
  try:
   with gzip.open(self.path,'wt') as f:
    while not self.stop.is_set() or not self.q.empty():
     try:x=self.q.get(timeout=.05)
     except queue.Empty:continue
     t=time.perf_counter();f.write(json.dumps(clean(x),separators=(',',':'),allow_nan=False)+'\n');self.times.append((time.perf_counter()-t)*1000);self.written+=1
  except Exception as e:self.error=repr(e)
 def close(self):
  self.stop.set();self.thread.join(10)
  if self.thread.is_alive():raise RuntimeError('RECORDER_STOP_TIMEOUT')
class Pipeline:
 def __init__(self,cfg,output,observer_factory=Observer):
  self.cfg=cfg.copy();self.output=Path(output);self.output.mkdir(parents=True,exist_ok=True);self.factory=observer_factory;self.input=LatestSlot();self.raw=None;self.analyzed_packet=None;self.state=None;self.lock=threading.Lock();self.status='STOPPED';self.events=[];self.counter=Counter();self.stop_event=threading.Event();self.source=None;self.worker=None;self.publisher=None;self.start_time=time.monotonic();self.timings={};self.samples=[];self.record=None;self.error=None;self.stages=deque(maxlen=300);self.ui_times=[];self.last_ui_key=None;self.transitions=[];self.metric_history=deque(maxlen=600);self.published=None
 def source_status(self,s):
  if s!=self.status:self.transitions.append({'elapsed':time.monotonic()-self.start_time,'status':s});self.status=s
 def receive(self,p):
  try:p.validate()
  except Exception as e:self.counter['invalid_packets']+=1;self.source_status('INVALID_PACKET:'+str(e));return
  self.counter['bridge_received']+=1
  with self.lock:self.raw=p
  self.input.put(p)
 def start(self,source_factory=None):
  if self.worker and self.worker.is_alive():raise RuntimeError('ALREADY_RUNNING')
  self.stop_event.clear();self.start_time=time.monotonic();self.input=LatestSlot();self.raw=None;self.analyzed_packet=None;self.state=None;self.counter=Counter();self.timings={};self.samples=[];self.error=None;self.metric_history.clear()
  self.record=Recorder(self.output/'states.jsonl.gz',self.cfg.get('record_queue',32))
  self.worker=threading.Thread(target=self.work,name='observation-worker',daemon=True);self.worker.start()
  self.publisher=threading.Thread(target=self.publish,name='ttl-state-publisher',daemon=True);self.publisher.start()
  if source_factory:self.source=source_factory(self.receive,self.source_status)
  elif self.cfg['source_mode']=='REALTIME_REPLAY':self.source=RecordedVideoFrameSource(self.cfg['video'],self.receive,self.source_status,self.cfg['speed'],self.cfg['loop'])
  else:
   from live_adapter import LiveCameraFrameSource
   self.source=LiveCameraFrameSource(self.cfg,self.receive,self.source_status,self.output)
  self.source.start();return self
 def work(self):
  continuity=Continuity(self.cfg['max_pts_gap_s'])
  try:
   observer=self.factory(self.cfg)
   while not self.stop_event.is_set() or self.input.peek() is not None:
    self.input.event.wait(.03);p=self.input.take()
    if p is None:continue
    try:reset,reason=continuity.check(p)
    except ValueError as e:self.counter['continuity_rejections']+=1;self.source_status('INVALID_PACKET:'+str(e));continue
    if p.age_ms()>self.cfg['ttl_ms']:self.counter['analysis_expired']+=1;continue
    t=time.perf_counter()
    if self.cfg.get('analysis_delay_ms'):time.sleep(self.cfg['analysis_delay_ms']/1000)
    r=observer.analyze(p,reset);r.update(schema='F10Y_OBSERVATION_1.0',source_mode=p.source_mode,session_id=p.session_id,frame_id=p.frame_id,source_pts=p.source_pts,arrival_monotonic=p.arrival_monotonic,age_upper_bound_at_arrival_ms=p.age_upper_bound_at_arrival_ms,timestamp_quality=p.timestamp_quality,capture_timestamp=p.capture_timestamp,host_decode_timestamp=p.host_decode_timestamp,host_receive_timestamp=p.host_receive_timestamp,reset_reason=reason,completed_monotonic=time.monotonic(),training_ready=False,scientific_control_admitted=False)
    r['timings'].update(decode_ms=p.decode_ms,queue_age_ms=(t-p.arrival_monotonic)*1000,end_to_end_software_ms=p.age_ms())
    self.counter['processed']+=1
    if r['valid'] and p.age_ms()<=self.cfg['ttl_ms']:self.counter['fresh_valid']+=1
    if r.get('aggregation'):
     a=r['aggregation']['regions'][0];self.metric_history.append([p.session_id,p.frame_id,p.source_pts,a['count'],a['density_per_10k_px'],a['nn_px'],a['rg_px'],a['radial_px_s'],r['valid']])
    with self.lock:self.state=r;self.analyzed_packet=p
    for k,v in r['timings'].items():self.timings.setdefault(k,[]).append(v)
    self.record.submit(r)
  except Exception as e:self.error=traceback.format_exc();self.source_status('ANALYSIS_ERROR:'+repr(e))
 def snapshot(self):
  with self.lock:s=self.state;p=self.raw
  now=time.monotonic();age=(now-s['arrival_monotonic'])*1000+s['age_upper_bound_at_arrival_ms'] if s else None
  valid=bool(s and s['valid'] and age<=self.cfg['ttl_ms'] and self.status=='STREAMING' and p and p.session_id==s['session_id'])
  reason='FRESH' if valid else self.status if self.status!='STREAMING' else 'STALE' if age and age>self.cfg['ttl_ms'] else s.get('reason','WARMUP') if s else 'WAITING'
  return dict(raw=p,state=s,status=reason,source_status=self.status,valid=valid,age_ms=age,counters=dict(self.counter),analysis_skipped=self.input.overwritten,recorder_dropped=self.record.dropped if self.record else 0)
 def publish(self):
  proc=psutil.Process();proc.cpu_percent();lastsample=0
  while not self.stop_event.wait(.05):
   snap=self.snapshot();s=snap['state'];valid=snap['valid']
   self.published={'schema':'F10Y_M4_1.0','session_id':s['session_id'] if s else None,'frame_id':s['frame_id'] if s else None,'source_mode':self.cfg['source_mode'],'valid':valid,'state_age_ms':snap['age_ms'],'reason':snap['status'],'velocity':s['aggregation']['regions'][0]['mean_velocity'] if valid and s.get('aggregation') else None,'aggregation':s['aggregation']['status'] if valid and s.get('aggregation') else None,'six_parameters':None,'material_id':None,'training_ready':False}
   self.counter['state_published']+=1
   if time.monotonic()-lastsample>=1:
    lastsample=time.monotonic();self.samples.append({'elapsed_s':lastsample-self.start_time,'rss_mib':proc.memory_info().rss/2**20,'cpu_percent':proc.cpu_percent(),'processed':self.counter['processed'],'age_ms':snap['age_ms']})
 def event(self,state,source='SIMULATED_EVENT',channel='ALL',note='',conditions=None):
  if state not in ['ON','OFF'] or source not in ['MANUAL_ANNOTATION','DEVICE_TELEMETRY','SIMULATED_EVENT']:raise ValueError('EVENT_SCHEMA')
  p=self.raw;e=dict(event_id=uuid.uuid4().hex,channel=channel,state=state,source=source,command_time=None,actual_execution_time=None,camera_time=None,source_pts=p.source_pts if p else None,session_id=p.session_id if p else None,host_event_monotonic=time.monotonic(),time_sync_quality='HOST_ONLY_EXPOSURE_UNSYNCHRONIZED',conditions=conditions or {},note=note,hardware_control=False)
  self.events.append(e);dump(self.output/'pzt_events.json',self.events);return e
 def stop(self):
  if self.source:self.source.stop()
  self.stop_event.set();self.input.event.set()
  if self.worker:self.worker.join(15)
  if self.publisher:self.publisher.join(3)
  if self.record:self.record.close()
  self.source_status('STOPPED');self.published={'valid':False,'reason':'STOPPED','velocity':None,'aggregation':None,'six_parameters':None}
  if self.worker and self.worker.is_alive():raise RuntimeError('WORKER_STOP_TIMEOUT')
  self.summary=self.report();dump(self.output/'summary.json',self.summary);return self.summary
 def report(self):
  span=time.monotonic()-self.start_time
  return dict(identity=identity(),config=self.cfg,wall_s=span,status=self.status,error=self.error,counters=dict(self.counter),source_decoded=getattr(self.source,'decoded',None),source_sent=getattr(self.source,'sent',0),source_sessions=getattr(self.source,'sessions',0),bridge_overwritten=getattr(self.source,'overwritten',0),analysis_skipped=self.input.overwritten,recorder_dropped=self.record.dropped if self.record else 0,recorder_error=self.record.error if self.record else None,recorder_written=self.record.written if self.record else 0,record_ms=stats(self.record.times if self.record else []),stages={k:stats(v) for k,v in self.timings.items()},fresh_valid_hz=self.counter['fresh_valid']/span if span else 0,analysis_hz=self.counter['processed']/span if span else 0,ui_refresh_hz=len(self.ui_times)/span if span else 0,ui_render_ms=stats(self.ui_times),resources=self.samples,transitions=self.transitions,events=self.events,threads_closed=not(self.worker and self.worker.is_alive()))
